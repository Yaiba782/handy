<?php
function set_rating_settings( $rating ) {

	$rating['settings']['star'] = array( 'class' => 'fa fa-star', 'color' => '#dd9933', 'class-menu' => 'fa fa-fw fa-star', 'class-menu-half' => 'fa fa-fw fa-star-half-o', 'class-menu-empty' => 'fa fa-fw fa-star-o');
	$rating['settings']['usd'] = array( 'class' => 'fa fa-usd', 'color' => '#6cbc3a', 'class-menu' => 'fa fa-fw fa-usd', 'class-menu-half' => 'fa fa-fw fa-usd', 'class-menu-empty' => 'fa fa-fw fa-usd', 'style' => 'opacity:.33');

	return $rating;
}
add_filter('rating_settings', 'set_rating_settings' );

function get_pages_cpt( $post_id ) {
	$cpt = 'destination-page';
	return $cpt;
}

function create_parent_slug( $post, $is_slug = false ) {
	if(!is_object($post))
		return '';

	$parents = get_post_ancestors( $post->ID );
	$parents_sort = array_reverse($parents);

	$slugs = array();
	foreach($parents_sort as $parent_id) {
		$parent_post = get_post($parent_id);
		$slugs[] = $parent_post->post_name;
	}
	$slugs[] = $post->post_name;

	$separator = ( $is_slug )? '/' : '-';
	return implode( $separator, $slugs );
}

function create_parent_front_slug( $post, $is_slug = false ) {
	$parents = get_post_ancestors( $post->ID );

	$parents_sort = array_reverse($parents);

	$slugs = array();
	foreach($parents_sort as $parent_id) {
		$master_id = get_master_parent($parent_id);
		$master = get_post($master_id);
		$slugs[] = $master->post_name;
	}
	$master_id = get_master_parent($post->ID);
	$master = get_post($master_id);
	$slugs[] = $master->post_name;

	return implode( '-', $slugs );
}

function create_parent_front_slug_nomaster( $post, $is_slug = false ) {
	$parents = get_post_ancestors( $post->ID );
	$dest_id = get_guide_page_parent($post->ID);
	$dest = get_post($dest_id);
	$dest_name = create_parent_slug( $dest );

	$parents_sort = array_reverse($parents);
	$slugs = array();
	foreach($parents_sort as $parent_id) {
		$parent_post = get_post($parent_id);
		$slugs[] = preg_replace('/'.$dest_name.'-/', '', $parent_post->post_name, 1);  //$parent_post->post_name;
	}
	$post_name = $post->post_name;
	if(defined('ICL_LANGUAGE_CODE') && substr($post_name, strlen($post_name)-6) == '-'.ICL_LANGUAGE_CODE.'-ge') {
	    $post_name = str_replace('-'.ICL_LANGUAGE_CODE.'-ge', '', $post_name);
	}
	$slugs[] = preg_replace('/'.$dest_name.'-/', '', $post_name, 1); //$post->post_name;
	return implode( '-', $slugs );
}

function destination_pages_list( $id = 0, $args = array() ) {
	global $post;

	$id = ( $id == 0 )? $post->ID : $id;
	$query = array(
				'post_type' => get_pages_cpt( $id ),
				'posts_per_page' => -1,
			);
	$pages = get_posts($query);
	$pages = get_page_hierarchy( $pages, $id );
	$start = count( get_post_ancestors( key($pages) ) );

	$output = "";

	$defaults = array(
		'mode' => 'list',     // or dropdown
		'size' => '4',        // min size for list
		'class' => 'postform'
	);

	$r = wp_parse_args( $args, $defaults );
	$mode = esc_attr( $r['mode'] );
	$size = esc_attr( $r['size'] );
	$class = esc_attr( $r['class'] );

	if ( !empty( $pages ) ) {
		$output.= '<select class="'.$class.'"'. (($mode == 'list')? ' size="'.$size.'"' : "").' >';
		foreach ( $pages as $id => $item ) {
			$level = count( get_post_ancestors( $id ) );
			$output.= '<option value="' . esc_attr( $id ). '">' . esc_html( str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level - $start) . get_the_title($id) ) . '</option>';
		}
		$output.= '</select>';
	}

	echo $output;
}

function destination_list( $id = 0, $args = array() ) {
	global $post;

	$id = ( $id == 0 )? $post->ID : $id;
	$query = array(
				'post_type' => 'destination',
				'posts_per_page' => -1,
			);
	$pages = get_posts($query);
	$pages = get_page_hierarchy( $pages, $id );
	$start = count( get_post_ancestors( key($pages) ) );

	$output = "";

	$defaults = array(
		'mode'  => 'list',    // or dropdown
		'size'  => '4',       // min size for list
		'class' => 'postform'
	);

	$r = wp_parse_args( $args, $defaults );
	$mode = esc_attr( $r['mode'] );
	$size = esc_attr( $r['size'] );
	$class = esc_attr( $r['class'] );

	if ( !empty( $pages ) ) {
		$output.= '<select class="'.$class.'"'. (($mode == 'list')? ' size="'.$size.'"' : "").' >';
		foreach ( $pages as $id => $item ) {
			$level = count( get_post_ancestors( $id ) );
			$output.= '<option value="' . esc_attr( $id ). '">' . esc_html( str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level - $start) . get_the_title($id) ) . '</option>';
		}
		$output.= '</select>';
	}

	echo $output;
}

function get_guide_page_level( $post_id ) {
	$meta = get_post_meta( $post_id, 'guide_page_level' );
	$level = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $level;
}

function get_guide_page_parent( $post_id ) {
	$meta = get_post_meta( $post_id, 'destination_parent_id' );
	$id = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $id;
}

function get_master_parent( $post_id ) {
	$meta = get_post_meta( $post_id, 'master_parent_id' );
	$id = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $id;
}

function get_guide_pages_slugs( $post_id ) {
	$post = get_post($post_id);
	$meta = get_post_meta( $post_id, 'pages_cpt_slug_' . $post->post_name );
	$slugs = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : '';

	return json_decode($slugs);
}

function get_guide_pages_slugs_new( $post_id ) {
	$post = get_post($post_id);
	$meta = get_post_meta( $post_id, 'pages_cpt_slug' );
	if(isset($meta[0]) && ! empty($meta[0])) {
		$slugs = json_decode($meta[0]);
	} else {
		$slugs = new stdClass();
	}

	return $slugs;
}

function get_guide_page_no_master( $post_id ) {
	$meta = get_post_meta( $post_id, 'no_master' );
	$val = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $val;
}

function get_guide_page_GUI( $post_id ) {
	$meta = get_post_meta( $post_id, 'destination_master_GUI' );
	$val = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $val;
}

function get_destination_gmaps_options( $post_id ) {
	$options = get_destination_options( $post_id );
	$intro = get_post_meta( $post_id, 'destination_intro' );

	$google_map = ( isset($options['google_map']) && !empty($options['google_map']) )? $options['google_map'] : array();

	$attrs = array();
	$attrs['latitude'] = isset($google_map['latitude'])? $google_map['latitude'] : '';
	$attrs['longitude'] = isset($google_map['longitude'])? $google_map['longitude'] : '';
	$attrs['zoom'] = isset($google_map['zoom'])? $google_map['zoom'] : '';
	$attrs['show_directory_pins'] = (isset($google_map['show_directory_pins']) && $google_map['show_directory_pins'] == 'true') ? true : false;
	$attrs['show_child_pins'] = (isset($google_map['show_child_pins']) && $google_map['show_child_pins'] == 'true') ? true : false;
	$attrs['show_current_pin'] = (isset($google_map['show_current_pin']) && $google_map['show_current_pin'] == 'true') ? true : false;
	$attrs['title'] = get_the_title( $post_id );
	$attrs['intro'] = ( isset($intro[0]) && !empty($intro[0])) ? $intro[0] : '';
	$attrs['link'] = get_the_permalink( $post_id );
	if(has_post_thumbnail( $post_id )) {
		$attachment_id = get_post_thumbnail_id( $post_id );
		$img = wp_get_attachment_image_src( $attachment_id, 'medium' );
		$attrs['image'] = '<img src="'. esc_url($img[0]).'" width="'.$img[1].'" height="'.$img[2].'">';
		$attrs['image_src'] = $img[0];
	} else {
		$attrs['image'] = '';
		$attrs['image_src'] = '';
	}

	return $attrs;
}

function has_gmaps_location( $post_id ) {

	// $dest_id = get_the_destination_ID($post_id);
	// $options = get_destination_options( $dest_id );

	if (get_post_type($post_id) == 'destination') {
		$options = get_destination_options( $post_id );
	// } elseif (get_post_type($post_id) == 'destination-page') {
		// $dest_id = get_the_destination_ID($post_id);
		// $options = get_destination_options( $dest_id );
	} elseif(get_post_type($post_id) == 'travel-directory') {
		$options = get_meta_guide_lists_details( $post_id );
	} else {
		// a generic check for postmeta...
	}
	return ( !empty($options['google_map']['longitude']) && !empty($options['google_map']['latitude']) )? true : false;
}

function show_destination_map( $post_id ) {

	// Current page
	if ( has_gmaps_location($post_id) )
		return $post_id;

	// Parent Destination
	$dest_id = get_the_destination_ID($post_id);
	if ( has_gmaps_location($dest_id) )
		return $dest_id;

	// otherwise...
	return false;
}


function get_directory_gmaps_options( $post_id ) {
	$options = get_meta_guide_lists_details( $post_id );
	$intro = '';
	$intro_text = get_post_meta( $post_id, 'guide_lists_intro' );
	if (is_array($intro_text)) {
		foreach ($intro_text as $text) {
			if (!empty($text)) {
				$intro = $text;
			}
		}
	}

	$google_map = ( isset($options['google_map']) && !empty($options['google_map']) )? $options['google_map'] : array();
	$attrs = array();
	$attrs['latitude'] = isset($google_map['latitude'])? $google_map['latitude'] : '';
	$attrs['longitude'] = isset($google_map['longitude'])? $google_map['longitude'] : '';
	$attrs['zoom'] = isset($google_map['zoom'])? $google_map['zoom'] : '';
	$attrs['title'] = get_the_title( $post_id );
	$attrs['intro'] = $intro;
	$attrs['link'] = get_the_permalink( $post_id );
	if(has_post_thumbnail( $post_id )) {
		$attachment_id = get_post_thumbnail_id( $post_id );
		$img = wp_get_attachment_image_src( $attachment_id, 'medium' );
		$attrs['image'] = '<img src="'.esc_url($img[0]).'" width="'.$img[1].'" height="'.$img[2].'">';
		$attrs['image_src'] = $img[0];
	} else {
		$attrs['image'] = '';
		$attrs['image_src'] = '';
		$url = '';
	}

	$attrs['rating'] = '';
	$rating_data = get_guide_lists_rating( $post_id );
	$ratings = array();
	if (isset($rating_data['enabled']) && !empty($rating_data['enabled'])) {
		foreach ($rating_data['enabled'] as $type => $enabled) {

			if ($type == 'menu_order' || $enabled !== 'true')
				continue;

			$key = str_replace('rating_types_', '', $type);
			if (isset($rating_data['settings'][$key]) && isset($rating_data[$type])) {
				$ratings[$key] = $rating_data['settings'][$key];
				$ratings[$key]['value'] = $rating_data[$type];
			}
		}
	}
	if (!empty($ratings)) {
		ob_start();
		foreach ($ratings as $key => $data) {
			?>
			<div class="rating-container">
				<span class="rating <?php echo 'rating-'. esc_attr($key); ?>">
					<div class="ratebox " data-id="<?php echo '-'. esc_attr($key); ?>" data-rating="<?php echo esc_attr($data['value']); ?>" data-state="rated"></div>
					<input type="hidden" class="rate-class"  value="<?php echo esc_attr($data['class']); ?>">
					<input type="hidden" class="rate-color"  value="<?php echo esc_attr($data['color']); ?>">
					<input type="hidden" class="rating-is-front"  value="true">
					<span class="infobox-value-rating"><?php echo $data['value']; ?></span>
				</span>
			</div>
			<?php
		}
		$attrs['ratings'] = ob_get_clean();
	}

	return $attrs;
}

function get_children_destination_gmaps_options( $post_id, $pins ) {
	$children = get_children($post_id);
	if(count($children) > 0 ) {
		foreach($children as $child) {
			$pins[$child->ID] = get_destination_gmaps_options($child->ID);
			$pins = get_children_destination_gmaps_options( $child->ID, $pins );
		}
	}
	return $pins;
}

function get_children_directory_gmaps_options( $post_id, $pins ) {
	$children = get_children($post_id);
	if(count($children) > 0 ) {
		foreach($children as $child) {
			$args = array(
				'post_type' => 'travel-directory',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => 'destination_parent_id',
						'value' => $child->ID
					)
				)
			);
			$items = get_posts( $args );
			foreach($items as $item) {
				$pins[$item->ID] = get_directory_gmaps_options($item->ID);
			}
			$pins = get_children_directory_gmaps_options( $child->ID, $pins );
		}
	}
	return $pins;
}

function is_master_page_disabled( $post_id ) {
	$meta = get_post_meta( $post_id, 'is_disabled_master_page' );
	$id = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $id;
}

function is_guide_page_disabled( $post_id ) {
	$meta = get_post_meta( $post_id, 'is_disabled_guide_page' );
	$id = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $id;
}

function update_pages_slug( $post_id, $post_name_new, $post_name_old  ) {
	$dest = get_post( $post_id );
	$slugs = get_guide_pages_slugs_new( $post_id );

	if(count($slugs)) {
		foreach($slugs as $key => $slug) {
			$val = explode('/', $slug);
			$level = count(get_post_ancestors($post_id));
			$val[$level] = $dest->post_name;
			$slugs->$key = implode('/', $val);
		}
	}

	$meta_name = 'pages_cpt_slug';
	update_post_meta( $post_id, $meta_name, json_encode($slugs));
}

function get_children_nomaster_pages( $children, $data_table, $level, $parent_id ) {
	if(count($children) > 0 ) {
		foreach($children as $child) {
			$link = 'post.php?post='.$child->ID.'&action=edit';
			$title_link = '<a href="'.$link.'" style="font-weight: bold; font-size:14px">' . str_repeat('— ', $level) . $child->post_title . '</a>';
			$user = get_user_by( 'id', $child->post_author );
			array_push( $data_table, array('ID' => $child->ID, 'title' => $title_link, 'author' => $user->display_name, 'date' => date('F j, Y', strtotime($child->post_date)) ) );

			$children = get_children ($child->ID);
			if(count($children)) {
				$data_table = $this->get_children_nomaster_pages( $children, $data_table, $level+1, $child->ID );
			}
		}
	}
	return $data_table;
}

function clear_guide_page_slug( $slugs, $slug ) {
	if(!empty($slugs)) {
		foreach($slugs as $key => $val) {
			if($val == $slug) {
				$parts = explode('/', $key);
				$post_name = $parts[count($parts) - 1];
				$id = get_id_by_post_name($post_name);
				//if(! $id) {
					unset($slugs->$key);
				//}
			}
		}
	}

	return $slugs;
}

function set_guide_pages_slugs( $post_id, $post, $is_nomaster = false ) {

	$slugs = get_guide_pages_slugs_new($post_id);

	$dest = get_post( $post_id );
	$dest_slug = create_parent_slug( $dest, true );
	$dest_name = create_parent_slug( $dest );
	$post_slug = create_parent_slug( $post, true );
	//$post_name = $is_nomaster? $post->post_name : create_parent_slug( $post );
	$post_name = $post->post_name;
	$post_front_slug = $is_nomaster? create_parent_front_slug_nomaster( $post ) : create_parent_front_slug( $post );

	$parent_post = get_post($post->post_parent);
	$post_parent_slug = create_parent_slug( $parent_post, true );
	if(empty($post_parent_slug)) {
		$post_parent_slug = $post_name = $dest_name.'-'.$post_name;
	}
	$post_parent_name = create_parent_slug( $parent_post );

	$key = ($post_parent_slug == $post_name)? $post_name : $post_parent_slug.'/'.$post_name;
	$slug = $dest_slug.'/'.$post_front_slug;
	$new_post_name = $post_name;

	$slugs = clear_guide_page_slug( $slugs, $slug );
	$slugs->$key = $slug;

	update_post_meta( $post_id, 'pages_cpt_slug', json_encode($slugs));
	return $new_post_name;
}

function update_guide_pages_slugs( $post, $is_nomaster = false ) {

	$dest_id = get_guide_page_parent($post->ID);
	$slugs = get_guide_pages_slugs_new($dest_id);

	$dest = get_post($dest_id);
	$dest_slug = create_parent_slug( $dest, true );

	$post_slug = create_parent_slug( $post, true );	
	$post_front_slug = $is_nomaster? create_parent_front_slug_nomaster( $post, false ) : create_parent_front_slug( $post );

	$slug = $dest_slug.'/'.$post_front_slug;
	$slugs = clear_guide_page_slug( $slugs, $slug );
	$slugs->$post_slug = $slug;

	update_post_meta( $dest_id, 'pages_cpt_slug', json_encode($slugs));
}

function set_pages_slug( $post_id, $master_pages ) {
	$dest = get_post( $post_id );
	$dest_slug = create_parent_slug( $dest, true );
	$dest_slug_key = str_replace('/', '-', $dest_slug);

	$meta_name = 'pages_cpt_slug_' . $dest->post_name;
	foreach((array)$master_pages->posts as $master) {
		$parent_post_name = '';
		if( $master->post_parent ) {
			$parent_post = get_post($master->post_parent);
			$parent_post_name = $parent_post->post_name;
		}

		$slug_page = create_parent_slug( $master, true );
		$key = $dest_slug_key.'-'.str_replace('/', '-', $slug_page);
		$slugs[$key] = $dest_slug . '/' . $slug_page;
	}

	update_post_meta( $post_id, $meta_name, json_encode($slugs));
}

function set_guide_page_level( $post_id, $level = 0 ) {
	update_post_meta( $post_id, 'guide_page_level', $level );
}

function set_guide_page_order( $post_id, $master_post_id ) {
	$meta_master_order = get_post_meta( $master_post_id, 'master_order' );
	$master_order = (isset($meta_master_order[0]) && ! empty($meta_master_order[0]))? $meta_master_order[0] : 0;
	update_post_meta( $post_id, 'guide_page_order', $master_order );
}

function set_guide_page_parent( $post_id, $parent_id = 0 ) {
	update_post_meta( $post_id, 'destination_parent_id', $parent_id );
}

function set_master_parent( $post_id, $parent_id = 0 ) {
	update_post_meta( $post_id, 'master_parent_id', $parent_id );
}

function set_guide_page_GUI( $post_id, $value ) {
	update_post_meta( $post_id, 'destination_master_GUI', $value );
}

function set_guide_page_no_master( $post_id ) {
	update_post_meta( $post_id, 'no_master', 1 );
}

function need_show_articles( $id = 0 ) {
	global $post;

	$id = ( $id == 0 )? $post->ID : $id;
	$options = get_destination_options( $id );

	if( $options['include_posts_home'] == 'false' )
		return false;
	else
		return true;
}

function blog_posts_query( $id = 0 ) {
	global $post;

	$id = ( $id == 0 )? $post->ID : $id;
	$options = get_destination_options( $id );

	$include_child_posts = ( isset( $options['include_posts_child'] ) && $options['include_posts_child'] == 'true' )? true : false;

	$categories = isset($options['blog_categories'])? $options['blog_categories'] : array();

	if( $include_child_posts ) {
		$children = get_children($id);
		foreach($children as $child) {
			$options = get_destination_options( $child->ID );
			$categories_ext = isset($options['blog_categories'])? $options['blog_categories'] : array();
			$categories = array_merge($categories, $categories_ext);
		}
	}

	if( ! empty($categories) ) {
		$query = array(
			'post_type' => 'post',
			'posts_per_page' => -1,
		);

		if( !empty($categories) ) {
			$query['tax_query'] = array(
				array(
					'taxonomy' => 'category',
					'field'    => 'id',
					'terms' => $categories
				)
			);
		}

		return new WP_Query($query);
	} else {
		return array();
	}
}

function get_destinations( $parent_id = 0 ) {
	$args = array(
		'post_type' => 'destination',
		'post_parent' => $parent_id,
		'posts_per_page' => -1,
		'orderby' => 'title',
		'order' => 'ASC',
	);
	$destinations = ( $parent_id == 0 )? get_posts( $args ) : get_children( $args );

	return $destinations;
}

function get_default_info_page_id($trid) {
	global $wpdb;

	$query = "SELECT element_id FROM $wpdb->prefix"."icl_translations WHERE trid = ".$trid." AND element_type = 'post_destination-page' AND isnull(source_language_code)";//" = '".ICL_LANGUAGE_CODE."'"; 
	$res = $wpdb->get_results($query, OBJECT);
	$elm_src_id = $res[0]->element_id;

	return $elm_src_id;
}

function has_info_page_master($trid) {
	$elm_src_id = get_default_info_page_id($trid);
	$src_master_page_id = get_master_parent($elm_src_id);
	$master_page_id = (int)apply_filters( 'wpml_object_id', $src_master_page_id, 'master-pages', false, ICL_LANGUAGE_CODE );
	if(!$master_page_id)
		return 0;
	$master_page = get_post($master_page_id);

	return $master_page;
}

function has_info_page_destination($trid) {
	$elm_src_id = get_default_info_page_id($trid);
	$src_dest_id = get_guide_page_parent($elm_src_id);
	$dest_id = (int)apply_filters( 'wpml_object_id', $src_dest_id, 'destination', false, ICL_LANGUAGE_CODE );
	if(!$dest_id)
		return 0;
	$dest = get_post($dest_id);

	return $dest;
}

function get_trid_by_ID($id) {
	$wpml_element_type = apply_filters( 'wpml_element_type', get_post_type($id) );
 	$args = array('element_id' => $id, 'element_type' => $wpml_element_type );
 	$origin = apply_filters( 'wpml_element_language_details', null, $args );
	$origin_trid = $origin->trid? $origin->trid : 0;

	return $origin_trid;
}

function get_destination_id_by_trid($trid) {
	global $wpdb;

	$query = "SELECT element_id FROM $wpdb->prefix"."icl_translations WHERE trid = ".$trid." AND element_type = 'post_destination-page'"; 
	$elms = $wpdb->get_results($query, OBJECT);

	$ids = array();
	foreach($elms as $elm) {
		$ids[] = $elm->element_id;
	}

	$id = (int)apply_filters( 'wpml_object_id', get_guide_page_parent(min($ids), 'destination', false, ICL_LANGUAGE_CODE ));
	return $id;
}

function get_destination_page_id_by_trid($trid, $lang) {
	global $wpdb;

	$query = "SELECT element_id FROM $wpdb->prefix"."icl_translations WHERE trid = ".$trid." AND element_type = 'post_destination-page' AND language_code = '".$lang."'"; 
	$elms = $wpdb->get_results($query, OBJECT);
	foreach($elms as $elm) {
		$id = $elm->element_id;
	}
	return $id;
}

function get_destination_pages( $post_id = 0, $return = 'list', $lang = false ) {
	$options  = get_option(get_travel_guide_option_key('travel_guide_options'));
	$settings = $options ? json_decode( $options, true ) : array();
	$page_base = '';
	if($lang) {
		$options = get_option(get_travel_guide_option_key('travel_guide_options', $lang));
		$settings_lang = $options ? json_decode( $options, true ) : array();
	}

	$args = array(
		'post_type' => get_pages_cpt($post_id),
		'posts_per_page' => -1,
		'meta_key' => 'guide_page_order',
		'orderby' => 'meta_value_num',
		'order' => 'ASC',
		'suppress_filters' => $lang? 1 : 0,
		'meta_query' => array(
			array(
				'key' => 'is_disabled_master_page',
				'compare' => 'NOT EXISTS'
			),
			array(
				'key' => 'is_disabled_guide_page',
				'compare' => 'NOT EXISTS'
			),
			array(
				'key' => 'destination_parent_id',
				'value' => $lang? (int)apply_filters( 'wpml_object_id', $post_id, 'destination', false, $lang ) : $post_id
			)
		)
	);

	if ($return == 'query')
		return $args;

	// Get the posts
	$guide_pages = get_posts( $args );
	if ($return == 'posts')
		return $guide_pages;

	$items = get_page_hierarchy( $guide_pages );
	$dest = get_post($post_id);
	$dest_slug = create_parent_slug( $dest, true );
	$pages_slugs = get_guide_pages_slugs_new( $post_id );

	$info = array();
	foreach($items as $key => $item) {
		$level = count(get_post_ancestors($key));
		$info[$key]['id'] = $key;
		$info[$key]['title'] = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level) . get_the_title($key);
		$info[$key]['link'] = get_permalink($key); // '';

		if( $level ) {
			$item_post = get_post($key);
			$item = create_parent_slug($item_post, true);
		}

		if (isset($pages_slugs->$item)) {
			if(defined('ICL_LANGUAGE_CODE')) {
				$info[$key]['link'] = str_replace($item, $pages_slugs->$item, $info[$key]['link']);
				$info[$key]['link'] = ($lang)? apply_filters( 'wpml_permalink', $info[$key]['link'], $lang ) : $info[$key]['link'];
				$info[$key]['link'] = ($lang)? str_replace('/'.$settings['page_base'].'/','/'.$settings_lang['page_base'].'/', $info[$key]['link']) : $info[$key]['link'];
			} else {
				$info[$key]['link'] = get_post_type_archive_link( get_pages_cpt($key) ) . $pages_slugs->$item;
				$info[$key]['link'] = str_replace('/'.$dest_slug, '/'.$dest_slug.$page_base, $info[$key]['link']);
			}
		}
	}

	return $info;
}

function get_hero_data( $id = 0 ) {
	global $post;

	$id = ( $id == 0 )? $post->ID : $id;

	$item = get_post($id);

	$hero['name'] = $item->post_title;
	$hero['breadcrumb'] = array();
	$parents = array_reverse( get_post_ancestors( $item->ID ) );

	foreach($parents as $key => $item) {
		$item = (defined('ICL_LANGUAGE_CODE'))? (int)apply_filters( 'wpml_object_id', $item, 'destination', true, ICL_LANGUAGE_CODE ) : $item;
		$hero['breadcrumb'][$key]['title'] = get_the_title($item);
		$hero['breadcrumb'][$key]['link'] = get_permalink($item);
	}
	return $hero;
}

function get_all_children( $post_id = 0, $all_destinations ) {
	$children = get_children($post_id);
	if(count($children)) {
		foreach($children as $key => $child) {
			$all_destinations[] = $key;
		}
		$all_destinations = get_all_children($child->ID, $all_destinations);
	}

	return $all_destinations;
}

function sort_directory_terms( $terms_unsorted = array() ) {
	$terms_tmp = array();
	$terms_sorted = array();
	$terms_excl = array();

	foreach($terms_unsorted as $key => $term) {
		$term_data = get_option('taxonomy_'.$term->term_id);
		$term_data['menu_order'] = !empty( $term_data['menu_order'] )? $term_data['menu_order'] : 0;
		$new_keys[] = array( 'key' => $key, 'order' => $term_data['menu_order'] );
		if (array_key_exists($term_data['menu_order'], $terms_tmp)) {
			$terms_excl[] = array( 'term' => $term, 'menu_order' => $term_data['menu_order'] );
		} else
			$terms_tmp[$term_data['menu_order']] = $term;
	}
	ksort($terms_tmp);

	foreach($terms_tmp as $key => $term) {
		$terms_sorted[] = $term;
		foreach($terms_excl as $term_excl) {
			if( $key == $term_excl['menu_order'] )
				$terms_sorted[] = $term_excl['term'];
		}
	}

	return $terms_sorted;
}

function get_destination_options( $post_id = 0 ) {
	$meta = get_post_meta( $post_id, 'destination_options' );
	$options = empty($meta[0])? '' : json_decode($meta[0], true);

	return $options;
}

function get_guide_lists_directory( $post_id = 0 ) {
	global $post;

	$post_id = ( $post_id == 0 )? $post->ID : $post_id;
	$dest = get_post( $post_id );
	$options = get_destination_options( $post_id );
	$include_child_guide_lists = ( isset( $options['guide_lists'] ) && $options['guide_lists'] == 'true' )? true : false;

	$all_child_destinations[] = $post_id;
	if( $include_child_guide_lists ) {
		$all_child_destinations = get_all_children($post_id, $all_child_destinations);
	}

	$args = array(
		'post_type' => 'travel-directory',
		'posts_per_page' => -1,
		'orderby' => 'title',
		'order' => 'ASC',
		'post_status' => array( 'publish' ),
		'suppress_filters' => defined('ICL_LANGUAGE_CODE')? 0 : 1,
		'meta_query' => array(
			array(
				'key' => 'destination_parent_id',
				'value' => $all_child_destinations,
				'compare' => 'IN'
			)
		)
	);
	$guide_lists = get_posts( $args );

	$directory = array();
	$terms_unsorted = array();
	$terms = array();
	$images = array();
	foreach($guide_lists as $list) {
		$guides_terms = get_the_terms( $list->ID, 'travel-dir-category' );
		if( $guides_terms ) {
			$category = current($guides_terms);
			if( in_array($category->term_id, $terms) === false ) {
				if( in_array($category->term_id, $images) === false && has_post_thumbnail( $list->ID ) )
					$images[] = $category->term_id;
				$terms_unsorted[] = $category;
				$first_post_id[] = $list->ID;
				$terms[] = $category->term_id;
			}
		}
	}

	$terms_sorted = sort_directory_terms( $terms_unsorted );
	foreach($terms_sorted as $key => $term) {
		$directory[$term->term_id]['post_ID'] = $term->object_id;
		$directory[$term->term_id]['name'] = $term->name;
		$directory[$term->term_id]['link'] = get_destination_taxonomy_term_links( $term->slug, $dest->post_name, 'travel-dir-category' );
		if( in_array($term->term_id, $images) ) {
			$directory[$term->term_id]['image'] = get_post_thumbnail_id( $term->object_id );
		}
	}
	return $directory;
}

function get_meta_guide_lists_details( $post_id ) {
	$meta = get_post_meta( $post_id, 'guide_lists_details' );
	$details_meta = empty($meta[0]) ? '' : json_decode(stripslashes($meta[0]), true);

	return $details_meta;
}

function get_guide_lists_details( $post_id ) {
	$details_meta = get_meta_guide_lists_details( $post_id );
	$details = array();
	if( isset($details_meta['address']) && !empty($details_meta['address']) )
		$details[__('Address', 'destinations')] = nl2br(esc_attr(str_replace("&lt;br /&gt;", "\r\n", $details_meta['address'])));
	if( isset($details_meta['contact_name_main']) && !empty($details_meta['contact_name_main']) )
		$details[$details_meta['contact_name_main']] = $details_meta['contact_value_main'];
	foreach($details_meta['contacts'] as $detail) {
		$details[key($detail)] = $detail[key($detail)];
	}
	if( isset($details_meta['other_name_main']) && !empty($details_meta['other_name_main']) )
		$details[$details_meta['other_name_main']] = $details_meta['other_value_main'];
	foreach($details_meta['other'] as $detail) {
		$details[key($detail)] = $detail[key($detail)];
	}

	return $details;
}

function get_meta_rating( $post_id ) {
	$meta = get_post_meta( $post_id, 'guide_list_rating' );
	$rating = empty($meta[0])? '' : json_decode($meta[0], true);

	return $rating;
}

function get_guide_lists_rating( $post_id ) {
	$rating = get_meta_rating( $post_id );
	$rating['star'] = (isset($rating['rating_types_star']) && !empty($rating['rating_types_star']))? $rating['rating_types_star'] : '';
	$rating['usd'] = (isset($rating['rating_types_usd']) && !empty($rating['rating_types_usd']))? $rating['rating_types_usd'] : '';

	$rating = apply_filters( 'rating_settings', $rating );
	unset($rating['settings'][0]);
	unset($rating['settings'][1]);

	$term = wp_get_post_terms( $post_id, 'travel-dir-category' );
	if( empty($term) ) {
		$rating['enabled']['rating_types_star'] = 'true';
		$rating['enabled']['rating_types_usd'] = 'true';
	} else
		$rating['enabled'] = get_option('taxonomy_'.$term[0]->term_id);

	return $rating;
}

function get_guide_lists_taxonomy( $post_id, $dest_slug ) {
	$taxonomy = wp_get_post_terms($post_id, 'travel-dir-category', array("fields" => "all"));

	$terms = array( 'name'=>'', 'link'=>'' );
	if (isset($taxonomy[0])) {
		$terms['name'] = $taxonomy[0]->name;
		$terms['link'] = get_destination_taxonomy_term_links( $taxonomy[0]->slug, $dest_slug, 'travel-dir-category' );
	}

	return $terms;
}

function get_guide_lists_by_category( $destination_id = 0, $category_id = 0, $return = 'posts' ) {

	$options = get_destination_options( $destination_id );
	$include_child_guide_lists = ( isset( $options['guide_lists'] ) && $options['guide_lists'] == 'true' )? true : false;

	$all_child_destinations[] = $destination_id;
	if( $include_child_guide_lists ) {
		$all_child_destinations = get_all_children($destination_id, $all_child_destinations);
	}

	$args = array(
				'post_type' => 'travel-directory',
				'posts_per_page' => -1,
				'post_status' => array( 'publish' ),
				'orderby' => 'title',
				'order' => 'ASC',
				'meta_query' => array(
					array(
						'key' => 'destination_parent_id',
						'value' => $all_child_destinations,
						'compare' => 'IN'
					)
				),
				'tax_query' => array(
					array(
						'taxonomy' => 'travel-dir-category',
						'field'    => 'id',
						'terms' => $category_id
					)
				)
			);

	$lists = get_posts( $args );

	$cat = isset($_GET['cat'])? $_GET['cat'] : 'star';
	$order = isset($_GET['order'])? $_GET['order'] : 'desc';
	$list = array();
	foreach($lists as $item) {
			$rating = get_meta_rating( $item->ID );
			$list[$item->ID] = isset($rating['rating_types_'.$cat])? $rating['rating_types_'.$cat] : 0;
	}

	if($order == 'desc')
		arsort($list);
	if($order == 'asc')
		asort($list);

	if ($return == 'Sorted IDs') {
		return array_keys($list);
	}

	$posts_sorted = array();
	foreach($list as $key => $item) {
		$posts_sorted[] = get_post($key);
	}

	/* Restore original Post Data */
	wp_reset_postdata();

	return $posts_sorted;
}

function get_destination_intro( $post_ID = 0 ) {
	global $post;

	switch ($post->post_type) {
		case 'destination':
			$meta_name = 'destination_intro';
			break;

		case 'destination-page':
			$meta_name = 'destination_intro';
			break;

		case 'travel-directory':
			$meta_name = 'guide_lists_intro';
			break;

		default:
			# code...
			break;
	}

	$id = ($post_ID) ? $post_ID : $post->ID;
	$meta = get_post_meta( $id, $meta_name );
	$intro = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : '';

	return $intro;
}

function get_destination_order( $post_id = 0 ) {
	$meta = get_post_meta( $post_id, 'destination_order' );
	$order = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $order;
}

function get_guide_page_order( $post_id = 0 ) {
	$meta = get_post_meta( $post_id, 'guide_page_order' );
	$order = (isset($meta[0]) && ! empty($meta[0]))? $meta[0] : 0;

	return $order;
}

function get_id_by_post_name($post_name) {
	global $wpdb;
	$id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '".$post_name."' AND post_status = 'publish'");
	return $id;
}

function get_destination_post( $post_id = 0 ) {

	if( $post_id == 0 ) {
		global $wp;
		$url = explode('/', home_url(add_query_arg(array(),$wp->request)));
		$name = $url[count($url) - 2];
		$dest_id = get_id_by_post_name( $name );
	} else {
		$dest_id = get_guide_page_parent( $post_id );
	}

	$dest = get_post($dest_id);
	return $dest;
}

function is_destination_paged( $args = array() ) {
	global $paged;
	if($paged)
		$args['paged'] = $paged;
	return $args;
}

function is_destination_archive( $args = array() ) {
	global $paged, $paged_cust;
	$paged = $paged_cust;
	if($paged)
		$args['paged'] = $paged;
	return $args;
}

function get_the_destination_ID() {
	global $post, $paged;

	$dest_id = 0;

	if(is_tax('destinations') || is_tax('travel-dir-category')) { // for taxonomy: destinations
		global $wp;

		$options  = get_option(get_travel_guide_option_key('travel_guide_options'));
		$settings = $options ? json_decode( $options, true ) : array();
		//$directory_base = (!isset($settings['guide_list_base']) || empty($settings['guide_list_base'])) ? '' : $settings['guide_list_base'];
		$directory_base = '';

		$request = !empty($directory_base)? str_replace($directory_base.'/', '', $wp->request) : $wp->request;
		$url = explode('/', home_url(add_query_arg(array(), $request)));

		$page_index = array_search('page', $url);
		$name_index = ($page_index)? count($url) - (count($url) - $page_index) - 2 : count($url) - 2;
		$paged = ($page_index)? intval($url[$page_index + 1]) : 0;

		$name = $url[$name_index];
		$dest_id = get_id_by_post_name( $name );
	} elseif (is_object($post)) {
		$dest_id = get_guide_page_parent($post->ID); // for post types: destination-page, travel-directory
	}

	if (!$dest_id && is_singular('destination')) {
		$dest_id = $post->ID; // for CPT destination single (destination home)
	}

	$dest_id = (defined('ICL_LANGUAGE_CODE'))? (int)apply_filters( 'wpml_object_id', $dest_id, 'destination', true, ICL_LANGUAGE_CODE ) : $dest_id;
	return $dest_id;
}

function get_the_destination_post() {
	$dest_id = get_the_destination_ID();
	$dest = get_post($dest_id);

	return $dest;
}

function get_guide_term_id() {
	global $wp, $paged;

	$url = explode('/', home_url(add_query_arg(array(),$wp->request)));

	$page_index = array_search('page', $url);
	$name_index = ($page_index)? count($url) - (count($url) - $page_index) - 1 : count($url) - 1;
	$paged = ($page_index)? intval($url[$page_index + 1]) : 0;//$page_index? $url[$page_index + 1] : 10;
	$name = ($pos = strpos($url[$name_index], '?lang='))? substr($url[$name_index], 0, $pos) : $url[$name_index];

	$term = get_term_by( 'slug', $name, 'travel-dir-category' );

	return $term;
}

function set_destinations_terms( $id ) {

	$post_terms = get_the_terms( $id, 'destinations');
	$post_terms_id = array();
	if (is_array($post_terms) && count($post_terms) && !is_wp_error($post_terms)) {
		foreach( $post_terms as $post_term ) {
			$post_terms_id[] = $post_term->term_id;
		}
	}

	$args = array(
		'orderby'    => 'name',
		'order'      => 'ASC',
		'hide_empty' => false,
	);
	$terms = get_terms( 'destinations', $args );
	if (count($terms)) {
		foreach( $terms as $term ) {
			if( ! in_array($term->term_id, $post_terms_id) )
				$post_terms_id[] = $term->term_id;
		}
	}

	$post_terms_id = array_map( 'intval', $post_terms_id );
	$term_taxonomy_ids = wp_set_object_terms( $id, $post_terms_id, 'destinations' );
}

function dest_get_words($text, $num_words = 10, $more = '&hellip;') {
	$trimmed = wp_trim_words( $text, $num_words, $more );
	return $trimmed;
}

function dest_get_characters($text, $count = 60, $more = '&hellip;') {
	if (strlen($text) <= $count){
		return $text;
	}

	$trimmed = substr( $text, 0, strrpos( substr( $text, 0, $count), ' ' ) );
	if (!empty($more)) {
		$trimmed .= $more;
	}
	return $trimmed;
}

function get_destination_settings() {

	// Retrieve settings
	$options  = get_option(get_travel_guide_option_key('travel_guide_options'));
	$settings = $options ? json_decode( $options, true ) : array();

	/**
	 * Test some defaults
	 */

	// Child destinations on parent Destinations front page
	if ( !isset($settings['number_posts_child']) || empty($settings['number_posts_child']) ) {
		$settings['number_posts_child'] = 2;
	}
	// "Pages" on parent Destinations front page
	if ( !isset($settings['number_posts_information']) || empty($settings['number_posts_information']) ) {
		$settings['number_posts_information'] = 5;
	}
	// Directory item categories on parent Destinations front page
	if ( !isset($settings['number_posts_directory']) || empty($settings['number_posts_directory']) ) {
		$settings['number_posts_directory'] = 6;
	}
	// Blog posts on parent Destinations front page
	if ( !isset($settings['number_posts_blogs']) || empty($settings['number_posts_blogs']) ) {
		$settings['number_posts_blogs'] = 3;
	}

	return apply_filters('get_destination_settings', $settings);
}

function get_sub_nav_links() {
	$settings = get_destination_settings();
	$links = array( 1 => 'information', 2 => 'directory' );

	$settings['menu_order_child'] = isset($settings['menu_order_child'])? $settings['menu_order_child'] : '';
	$settings['menu_order_blogs'] = isset($settings['menu_order_blogs'])? $settings['menu_order_blogs'] : '';

	$sub_nav_links[$settings['menu_order_child']] = 'places';
	if($settings['menu_order_child'] == $settings['menu_order_blogs']) {
		$sub_nav_links[] = 'articles';
	} else
		$sub_nav_links[$settings['menu_order_blogs']] = 'articles';

	$max = max(array_keys($sub_nav_links));
    for($i = 1, $j = 1; $i <= $max; $i++) {
        if(!isset($sub_nav_links[$i]) && $j <= 2)
            $sub_nav_links[$i] = $links[$j++];
    }

	if(!in_array('information', $sub_nav_links))
		$sub_nav_links[$max+1] = 'information';
	if(!in_array('directory', $sub_nav_links))
		$sub_nav_links[$max+2] = 'directory';

	ksort($sub_nav_links);

	return $sub_nav_links;
}

function get_destination_taxonomy_term_links( $term = false, $post_name = '', $taxonomy = 'destinations', $slug = '', $lang = false ) {
	$options  = get_option(get_travel_guide_option_key('travel_guide_options'));
	$settings = $options ? json_decode( $options, true ) : array();
	if($lang) {
		$options = get_option(get_travel_guide_option_key('travel_guide_options', $lang));
		$settings_lang = $options ? json_decode( $options, true ) : array();
	} 
	$directory_base = '';
	// if($term == 'places' || $term == 'articles')
	// 	$directory_base = '';
	// else
	// 	$directory_base = (!isset($settings['guide_list_base']) || empty($settings['guide_list_base'])) ? '' : $settings['guide_list_base'] . '/';

	// Build the URL
	if ( $term ) {
		// Add the slug
		$term_slug = $term.$slug;
		$term_link = get_term_link( $term_slug, $taxonomy );
		if (!is_wp_error($term_link)) {
			if(defined('ICL_LANGUAGE_CODE')) {
				$term_link = ($lang)? str_replace('/'.$settings['guide_list_base'].'/','/'.$settings_lang['guide_list_base'].'/', $term_link) : $term_link;
				$term_link = ($pos = strpos($term_link, '?lang='))? substr($term_link, 0, $pos) : $term_link;
				$term_link = (substr( $term_link, -1) == '/')? $term_link : $term_link . '/';
			}
			$find    = '/'.$term_slug.'/';
			$replace = '/'.$post_name.'/';
			$pos     = strrpos($term_link, $find); // find last occurance
			$url     = $term_link;                 // make sure we have a URL (fallback)
			// replace last occurance of the "term slug"
			if($pos !== false) {
				$url = substr_replace($term_link, $replace, $pos, strlen($find));
			}
			// add the term at the end
			$url .= $directory_base . $term;
			if(defined('ICL_LANGUAGE_CODE')) {
				if(!$lang) {
					global $sitepress;
					$lang = $sitepress->get_current_language();
				}
				$url = ($lang)? apply_filters( 'wpml_permalink', $url, $lang ) : $url;
			}

			return $url;
		}
	}

	return false;
}

function output_sub_menu_item( $id, $item, $echo = true ) {
	$dest = get_post( $id );
	$settings = get_destination_settings();

	ob_start();
	switch ($item) {
		case 'places':
			$places = get_destinations( $dest->ID );
			if( count($places) && $echo ):
				// Link URL
				$places_url = get_destination_taxonomy_term_links( 'places', $dest->post_name );
				$places_title = ( isset($settings['menu_title_child']) && !empty($settings['menu_title_child']) )? $settings['menu_title_child'] : __('Places', 'destinations');
				// List Item ?>
				<li><a href="<?php echo esc_url($places_url); ?>"><?php echo $places_title; ?></a></li>
			<?php endif;
			$items = $places;
			break;

		case 'information':
			$info_pages = get_destination_pages( $dest->ID );
			if( count($info_pages) && $echo ): ?>
				<li class="dropdown show-on-hover">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php _e('Information', 'destinations'); ?> <span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<?php foreach($info_pages as $info_page): ?>
								<li><a href="<?php echo esc_url($info_page['link']); ?>"><?php echo $info_page['title']; ?></a></li>
						<?php endforeach; ?>
					</ul>
				</li>
			<?php endif;
			$items = $info_pages;
			break;

		case 'directory':
			$directories = get_guide_lists_directory( $dest->ID );
			if( count($directories) && $echo ):

				// Temp method to get first value as main link.
				$first = reset($directories);
				$directory_url = (isset($first['link'])) ? esc_url($first['link']) : '#'; // '#';
				?>
				<li class="dropdown show-on-hover">
					<a href="<?php echo esc_url($directory_url); ?>" class="dropdown-toggle" data-toggle="dropdown"><?php _e('Directory', 'destinations'); ?> <span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<?php foreach($directories as $key => $directory):
							?>
							<li><a href="<?php echo esc_url($directory['link']); ?>"><?php echo $directory['name']; ?></a></li>
						<?php endforeach; ?>
					</ul>
				</li>
			<?php endif;
			$items = $directories;
			break;

		case 'articles':
			$articles = blog_posts_query( $dest->ID );
			if( isset($settings['menu_item_blogs']) && $settings['menu_item_blogs'] == 'true' && is_object($articles) && isset($articles->posts) && count($articles->posts) && $echo ):
				$articles_url = get_destination_taxonomy_term_links( 'articles', $dest->post_name );
				$articles_title = ( isset($settings['menu_title_blogs']) && !empty($settings['menu_title_blogs']) )? $settings['menu_title_blogs'] : __('Blog', 'destinations');
				?>
				<li><a href="<?php echo esc_url($articles_url); ?>"><?php echo $articles_title; ?></a></li>
			<?php endif;
			$items = $articles;
			break;
	}

	if ($echo) {
		echo ob_get_clean();
	}

	return $items;
}

function get_travel_guide_option_key($option_key, $lang = '') {
	if(defined('ICL_LANGUAGE_CODE')) {
		global $sitepress;
		$what_lang = empty($lang)? ICL_LANGUAGE_CODE : $lang;
	    $option_key = $what_lang . '_' . $option_key;
	}
	return $option_key;
}

#-----------------------------------------------------------------
# Filters wp_title to translate text for Places and Articles.
#-----------------------------------------------------------------

if ( ! function_exists( 'destinations_taxonomy_wp_title' ) ) :
function destinations_taxonomy_wp_title( $title, $sep ) {

	// Places in title
	if ( is_tax( 'destinations', 'places' ) ) {
		$places_title = __('Places', 'destinations');
		$title = preg_replace('/Places/', $places_title, $title, 1);
	}

	// Articles in title
	if ( is_tax( 'destinations', 'articles' ) ) {
		$articles_title = __('Articles', 'destinations');
		$title = preg_replace('/Articles/', $articles_title, $title, 1);
	}

	return $title;
}
endif; // destinations_taxonomy_wp_title
add_filter( 'wp_title', 'destinations_taxonomy_wp_title', 10, 2 );

if ( ! function_exists( 'filter_permalink_after_search' ) ) :
function filter_permalink_after_search( $url ) {
	global $post;

	if(!isset($_GET['s']))
		return $url;

	if($dest_id = get_guide_page_parent($post->ID)) {
		$slugs = get_guide_pages_slugs_new($dest_id);
		$item = create_parent_slug($post, true);

		if (isset($item) && !empty($item) && isset($slugs->$item)) {
			$url = get_post_type_archive_link( get_pages_cpt($post->ID) ) . $slugs->$item;
		}
	}

	return $url;
}
endif;
add_filter('the_permalink', 'filter_permalink_after_search');

if (!function_exists('unescaped_json')) :
function unescaped_json( $arr ) {
	return preg_replace_callback(
					    '/\\\\u([0-9a-f]{4})/i',
					    function ($matches) {
					        $sym = mb_convert_encoding(
					                pack('H*', $matches[1]), 
					                'UTF-8', 
					                'UTF-16'
					                );
						    return $sym;
					    },
					    json_encode($arr)
			);
}
endif;

#-----------------------------------------------------------------
# Filter for plugin: qtranslate X
#-----------------------------------------------------------------
if ( ! function_exists( 'get_qtranslate_rw' ) ) :
function get_qtranslate_rw( $text ) {
	if ( function_exists('qtranxf_use') ) {
		global $q_config;
		$text = qtranxf_use($q_config['language'], $text);
	}

	return $text;
}
add_filter('get_qtranslate_rw', 'get_qtranslate_rw' );
endif;